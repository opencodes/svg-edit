import {Component} from 'angular2/core';
import {CompaniesService} from './app.service';

@Component({
  selector: 'my-app', 
  template: `
  <div (click)="callService()">Test</div>
  <div *ngFor="#company of companies">{{company.name}}</div>
  `
})
export class AppComponent {

  constructor(private service:CompaniesService) {
  }
  
  callService() {
    this.service.getCompanies().subscribe(
      (companies) => {
        console.log(companies);
        this.companies = companies.list.Company;
        console.log(this.companies);
      });
  }
}